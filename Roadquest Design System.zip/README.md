# Roadquest Trucking Services — Design System

## Overview

**Roadquest Trucking Services** is a Philippine trucking and logistics company founded in 2025, based in **Marilao, Bulacan**. It is a sole proprietorship providing provincial deliveries and container hauling across **Luzon, Visayas, and Mindanao** — serving manufacturers, distributors, retail chains, and SMEs.

The product is a **marketing/service website** (Next.js + Tailwind CSS v4) that communicates reliability, speed, and affordability. The site includes pages for Home, About, Services, Fleet (Projects), and Contact.

### Sources
- **Codebase**: https://github.com/krankwa/RoadQuests (Next.js + Tailwind CSS v4)
- No Figma link was provided.

---

## Products

| Surface | Description |
|---|---|
| Marketing Website | Next.js app with 5 main pages: Home, About, Services, Fleet, Contact |

---

## CONTENT FUNDAMENTALS

**Tone**: Professional, dependable, direct. Copy is confident but not salesy. Speaks to business operators who need logistics they can trust.

**Voice**:
- Third-person brand ("Roadquest Trucking Services…") for formal sections
- Second-person "your" in headlines and CTAs ("Your Load, Our Mission", "Services Tailored to You")
- No first-person "I" — brand speaks as a collective ("we", "our")

**Casing**: Title Case for section headings. Sentence case for body copy. ALL CAPS not used.

**Emoji**: Not used in UI copy. Sparingly used in README/developer docs only.

**Copy examples**:
- Headline: *"Your Load, Our Mission"*
- Sub-headline: *"Safe, reliable, and cost-efficient trucking across Luzon, Visayas, and Mindanao"*
- CTA: *"Request Quote"*, *"Contact Us"*, *"Learn More"*
- Service names: "Provincial Deliveries", "Container Hauling", "Closed Van Transport", "Wing Van & Trailer Trucks"

**Length**: Concise. Body paragraphs are 2–4 sentences. Feature cards use 1-liner descriptions.

**Specificity**: Location names (Luzon, Visayas, Mindanao, Marilao Bulacan), truck types, and client types (manufacturers, distributors, retail chains, SMEs) are always named specifically.

---

## VISUAL FOUNDATIONS

### Colors
- **Primary background**: `#FFFFFF` (light) / `#1A1A1A` (dark)
- **Secondary background**: `#F5F5F5` (light) / `#2A2A2A` (dark) — used for page wrappers
- **Primary text**: `#1A1A1A` (light) / `#FFFFFF` (dark)
- **Secondary text**: `#4A4A4A` (light) / `#D0D0D0` (dark) — body copy, descriptions
- **Accent (Red)**: `#DC2626` (light) / `#EF4444` (dark) — primary CTA, highlights, icon backgrounds
- **Accent Alt (Green)**: `#16A34A` (light) / `#22C55E` (dark) — footer headings, trust signals
- **Status Positive**: green (same as accent-alt)
- **Status Negative**: red (same as accent)
- **Status Neutral**: `#CA8A04` (light) / `#EAB308` (dark) — amber

**Color vibe**: Clean white/light gray base with bold red as the action color. Green adds a secondary trust signal (reliability, go/positive). No gradients. No decorative color fills.

### Typography
- **Font**: Rubik (Google Fonts), weights 400 / 500 / 700
- **Hero h1**: font-black (800+), 4xl–6xl responsive, tight leading
- **Section h2**: font-extrabold (800), 3xl–5xl
- **Card h3**: font-bold (700), lg–2xl
- **Body**: Regular (400), base–xl, color text-secondary
- **No serif fonts used anywhere.**
- **Tracking**: Nav links use `tracking-[1px]` — slightly open letter-spacing

### Spacing & Layout
- Max container width with `container mx-auto px-4 sm:px-6 lg:px-8`
- Section vertical rhythm: `space-y-16` on main, `py-8 sm:py-12`
- Cards use `p-4` to `p-6` internal padding
- Grid: 1→2→4 column responsive grid for service/feature cards

### Cards
- Background: `bg-bg-primary` (white on light)
- Border: `border border-text-secondary/20` — subtle 10% gray border
- Radius: `rounded-xl` (12px)
- Shadow: `shadow-lg`, hover: `shadow-2xl` — elevation on hover
- Hover: border color shifts to `accent` on feature cards; `scale-105` on images

### Buttons
- **Primary**: `bg-accent text-bg-primary rounded-full px-6 py-3 font-medium` — solid red, pill shape
- **Outline**: `border-2 border-accent text-accent rounded-full` → hover fills with accent
- **Pill shape** (rounded-full) is the standard. No square buttons.
- **Hover**: `hover:opacity-90` on primary; fill swap on outline

### Backgrounds
- White or off-white (#F5F5F5) — no decorative gradients or textures
- Hero sections use full-bleed images with a dark overlay (`bg-text-primary/50`)
- No hand-drawn illustrations, no repeating patterns

### Imagery
- Photographic: real truck/logistics photography, team photos, engineer portraits
- Color: warm/natural tones, not stylized
- Treated with `object-cover` and `rounded-xl` corners
- Full-bleed hero images with dark 50% overlay for text legibility

### Animation
- **Framer Motion** used for scroll and entrance animations
- **Parallax scroll** on the client testimonials section
- Card hover: `transition-shadow duration-300`, `transition-transform duration-300`
- Nav underline: `scale-0 → scale-100` on hover via CSS transform
- Mobile menu: `opacity + translateY` toggle, `duration-300 ease-in-out`
- No bounces. No spring physics visible. Smooth ease transitions only.

### Borders & Dividers
- Divider lines: `border-t border-text-primary/50`
- Card borders: `border border-text-secondary/20`
- Nav border: `border-b border-text-secondary/10`
- Corner radii: `rounded-full` (buttons, icon circles), `rounded-xl` (cards, images), `rounded-lg` (logo), `rounded-md` (page wrappers)

### Iconography
- **FontAwesome Free** (solid + brands): used in navbar toggle, feature icons, social links
- **Tabler Icons (React)**: listed as a dependency, likely for supplemental icons
- Icon circles: `size-11 rounded-full bg-accent text-bg-primary` — red circle with white icon
- Social icons: wrapped in `size-12 rounded-full border border-text-primary`
- No custom SVG illustrations drawn in code
- No emoji in UI

### Elevation / Depth
- Navbar: `shadow-sm` + sticky top-0 with border-b
- Cards rest: `shadow-lg`
- Cards hover: `shadow-2xl`
- No blur/glassmorphism effects observed

### Transparency & Blur
- Hero overlay: `bg-text-primary/50` (50% dark tint over image)
- Nav border: `border-text-secondary/10`
- Card border: `border-text-secondary/20`
- No frosted glass / backdrop-blur

### Dark Mode
- Full dark mode support via CSS custom properties
- Triggered by `.dark` class on `<html>`
- All semantic color tokens flip automatically

---

## ICONOGRAPHY

### Icon Libraries Used
- **FontAwesome Free Solid** (`@fortawesome/free-solid-svg-icons`) — navigation icons (bars, xmark), feature icons (money-bill-wave, bolt, truck-fast, clock)
- **FontAwesome Free Brands** (`@fortawesome/free-brands-svg-icons`) — social icons (facebook, whatsapp)
- **Tabler Icons React** (`@tabler/icons-react`) — supplemental icon set; usage not explicitly observed in read code but installed

### Usage Patterns
- Feature icon: inside a `size-11 rounded-full bg-accent text-bg-primary` circle, `text-xl`
- Social icon: inside a `size-12 rounded-full border border-text-primary` ring, `text-4xl`
- Hamburger/close: inline in button, `text-xl`

### Assets Copied
- `assets/logo1.png` — primary business logo (also used as favicon)
- `assets/logo2.png` — alternate logo variant (used in footer)
- `assets/header-image.jpg` — hero/header truck image
- `assets/about-us.jpg` — about page hero image
- `assets/engineer.jpg` — services/team portrait
- `assets/project-1.jpg`, `project-2.jpg`, `project-3.jpg` — fleet/project images
- `assets/fleet-preview.jpg` — business partners / fleet preview image

---

## File Index

```
README.md                   — This file; design system overview
colors_and_type.css         — CSS custom properties for all tokens (color + type)
SKILL.md                    — Agent skill descriptor
assets/                     — Logos, images, brand photography
preview/                    — Design system card HTML files (shown in Design System tab)
ui_kits/
  website/
    index.html              — Interactive click-through prototype of the Roadquest website
    Navbar.jsx              — Navbar component
    Footer.jsx              — Footer component
    HomePage.jsx            — Home page sections
    AboutPage.jsx           — About page
    ServicesPage.jsx        — Services page
    ContactPage.jsx         — Contact page
```
