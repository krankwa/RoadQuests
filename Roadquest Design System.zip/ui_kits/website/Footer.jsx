// Roadquest — Footer Component

function RQFooter({ onNavigate }) {
  return (
    <>
      <div style={{ borderTop: '1px solid rgba(26,26,26,0.4)', marginTop: 40 }} />
      <footer style={{
        background: '#fff', padding: '40px 48px 24px',
        fontFamily: "'Rubik', sans-serif",
      }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32, marginBottom: 28 }}>
          {/* Logo + Social */}
          <div style={{ textAlign: 'center' }}>
            <img src="../assets/logo2.png" alt="Logo" style={{ width: 90, height: 90, objectFit: 'contain', display: 'block', margin: '0 auto 12px' }} />
            <div style={{ display: 'flex', justifyContent: 'center', gap: 10 }}>
              {[
                { label: 'FB', color: '#1877F2', icon: 'f' },
                { label: 'WA', color: '#25D366', icon: '📱' },
              ].map(s => (
                <div key={s.label} style={{
                  width: 44, height: 44, borderRadius: '9999px', border: '1px solid #1A1A1A',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: s.color,
                }}>{s.label}</div>
              ))}
            </div>
          </div>
          {/* Company */}
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#16A34A', marginBottom: 12 }}>Company</div>
            {['About Us','Our Services','Our Fleet','Request a Quote'].map(item => (
              <div key={item} style={{ marginBottom: 8 }}>
                <button onClick={() => onNavigate && onNavigate(item.replace('Our ','').replace('Request a Quote','Contact'))} style={{ background:'none', border:'none', cursor:'pointer', color:'#4A4A4A', fontSize:13, fontFamily:"'Rubik',sans-serif", padding:0 }}>{item}</button>
              </div>
            ))}
          </div>
          {/* Services */}
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#16A34A', marginBottom: 12 }}>Services</div>
            {['Provincial Deliveries','Container Hauling','Closed Van Transport','Wing Van & Trailer Trucks'].map(s => (
              <div key={s} style={{ color: '#4A4A4A', fontSize: 13, marginBottom: 8 }}>{s}</div>
            ))}
          </div>
          {/* Contact */}
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#16A34A', marginBottom: 12 }}>Contact</div>
            <div style={{ color:'#4A4A4A', fontSize:13, marginBottom:8 }}>9001 Laot Services Road Patubig, Marilao Bulacan</div>
            <div style={{ color:'#4A4A4A', fontSize:13, marginBottom:8 }}>roadquesttruckingservices@gmail.com</div>
            <div style={{ color:'#4A4A4A', fontSize:13 }}>+63 920-964-8531</div>
          </div>
        </div>
        <div style={{ textAlign: 'center', fontSize: 12, color: '#4A4A4A', borderTop: '1px solid rgba(0,0,0,.06)', paddingTop: 16 }}>
          Copyright © 2025 Roadquest Trucking Services. All rights reserved.
        </div>
      </footer>
    </>
  );
}

Object.assign(window, { RQFooter });
