// Roadquest — Home Page

function HomePage({ onNavigate }) {
  const whyUs = [
    { icon: <i className="fas fa-money-bill-wave"></i>, title: 'Lower Cost', desc: 'Competitive rates for every shipment size and route.' },
    { icon: <i className="fas fa-bolt"></i>, title: 'Fast Delivery', desc: 'On-time arrivals across Luzon, Visayas, and Mindanao.' },
    { icon: <i className="fas fa-truck"></i>, title: 'Reliable Fleet', desc: 'Closed vans, wing vans, and trailer trucks — well-maintained.' },
    { icon: <i className="fas fa-clock"></i>, title: '24/7 Service', desc: 'Dispatch and support whenever your business needs us.' },
  ];
  const [hoveredCard, setHoveredCard] = React.useState(null);

  return (
    <div style={{ fontFamily: "'Rubik', sans-serif" }}>
      {/* Hero */}
      <section style={{ textAlign: 'center', padding: '48px 40px 32px', maxWidth: 760, margin: '0 auto' }}>
        <h1 style={{ fontSize: 'clamp(2.2rem,5vw,3.5rem)', fontWeight: 900, lineHeight: 1.1, color: '#1A1A1A', margin: '0 0 14px' }}>
          Your Load, <span style={{ color: '#DC2626' }}>Our Mission</span>
        </h1>
        <p style={{ fontSize: 17, color: '#4A4A4A', marginBottom: 24, maxWidth: 520, margin: '0 auto 24px' }}>
          Safe, reliable, and cost-efficient trucking across Luzon, Visayas, and Mindanao — serving manufacturers, distributors, retail chains, and SMEs.
        </p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 12, flexWrap: 'wrap' }}>
          <RQButton text="Contact Us" size="lg" onClick={() => onNavigate('Contact')} />
          <RQButton text="Our Services" size="lg" variant="outline" onClick={() => onNavigate('Services')} />
        </div>
      </section>

      {/* Hero Image + Why Us */}
      <section style={{ display: 'flex', gap: 28, padding: '0 40px', alignItems: 'stretch', marginBottom: 56 }}>
        <div style={{ flex: '0 0 58%' }}>
          <img src="../assets/header-image.jpg" alt="Roadquest fleet" style={{
            width: '100%', height: 340, objectFit: 'cover', borderRadius: 16, display: 'block',
          }} />
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <h2 style={{ fontSize: 'clamp(1.4rem,2vw,2rem)', fontWeight: 800, color: '#1A1A1A', margin: '0 0 6px' }}>
            Why Choose <span style={{ color: '#16A34A' }}>Roadquest</span>
          </h2>
          <p style={{ fontSize: 14, color: '#4A4A4A', marginBottom: 16 }}>Built for businesses that depend on deliveries being on time, every time.</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, flex: 1 }}>
            {whyUs.map((item, i) => (
              <div key={item.title}
                onMouseEnter={() => setHoveredCard(i)}
                onMouseLeave={() => setHoveredCard(null)}
                style={{
                  display: 'flex', flexDirection: 'column', padding: '14px 14px', borderRadius: 12,
                  border: `1px solid ${hoveredCard === i ? '#DC2626' : 'rgba(74,74,74,0.2)'}`,
                  background: '#fff',
                  boxShadow: hoveredCard === i ? '0 8px 24px rgba(0,0,0,.1)' : 'none',
                  transition: 'all .2s', cursor: 'default',
                }}>
                <div style={{
                  width: 40, height: 40, borderRadius: '9999px',
                  background: '#DC2626', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 18, marginBottom: 8,
                }}>{item.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 14, color: '#1A1A1A' }}>{item.title}</div>
                <div style={{ fontSize: 12, color: '#4A4A4A', marginTop: 3, lineHeight: 1.5 }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section style={{ padding: '0 40px 48px', background: '#F5F5F5', paddingTop: 40, margin: '0 -0px' }}>
        <SectionHeading title="Services Tailored to You" subtitle="Comprehensive trucking and logistics services built for your business needs." />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {['Provincial Deliveries','Container Hauling','Closed Van Transport','Wing Van & Trailer Trucks'].map((s, i) => (
            <div key={s} style={{
              background: '#fff', borderRadius: 12, overflow: 'hidden',
              boxShadow: '0 4px 6px rgba(0,0,0,.07)', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 20, textAlign: 'center',
            }}>
              <div style={{ width: 120, height: 100, borderRadius: 10, overflow: 'hidden', marginBottom: 12 }}>
                <img src="../assets/engineer.jpg" alt={s} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, color: '#DC2626', marginBottom: 6 }}>{s}</div>
              <div style={{ fontSize: 12, color: '#4A4A4A', lineHeight: 1.5 }}>
                {['Reliable door-to-door deliveries across all provinces nationwide.',
                  'Efficient hauling of 20ft and 40ft containers from ports to warehouses.',
                  'Secure, weather-protected transport using our closed van fleet.',
                  'High-capacity services for bulk shipments and large-volume logistics.'][i]}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* About Us teaser */}
      <section style={{ display: 'flex', flexDirection: 'row-reverse', gap: 40, padding: '48px 40px', alignItems: 'center' }}>
        <div style={{ flex: 1 }}>
          <h2 style={{ fontSize: 'clamp(1.6rem,3vw,2.5rem)', fontWeight: 800, margin: '0 0 12px', color: '#1A1A1A' }}>About Us</h2>
          <p style={{ fontSize: 15, color: '#4A4A4A', lineHeight: 1.7, marginBottom: 20 }}>
            Established in 2025, Roadquest Trucking Services is a sole proprietorship based in Marilao, Bulacan, specializing in provincial deliveries and container hauling across Luzon, Visayas, and Mindanao.
          </p>
          <RQButton text="Learn More" onClick={() => onNavigate('About')} size="lg" />
        </div>
        <div style={{ flex: 1 }}>
          <img src="../assets/about-us.jpg" alt="About" style={{ width: '100%', borderRadius: 12, objectFit: 'cover', height: 280, display: 'block' }} />
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { HomePage });
