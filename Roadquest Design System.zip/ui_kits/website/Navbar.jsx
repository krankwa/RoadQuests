// Roadquest — Navbar Component

function RQNavbar({ currentPage, onNavigate }) {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const links = ['Home', 'About', 'Services', 'Fleet', 'Contact'];

  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 32px', background: '#fff', position: 'sticky', top: 0, zIndex: 50,
      borderBottom: '1px solid rgba(74,74,74,0.1)', boxShadow: '0 1px 2px rgba(0,0,0,.05)',
      height: 72,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <img src="../assets/logo1.png" alt="Logo" style={{ width: 60, height: 60, borderRadius: 8, objectFit: 'contain' }} />
        <div style={{ display: 'flex', gap: 2 }}>
          {links.map(link => {
            const active = currentPage === link;
            return (
              <button key={link} onClick={() => { onNavigate(link); setMenuOpen(false); }} style={{
                position: 'relative', padding: '8px 14px', fontSize: 15, fontWeight: 700,
                letterSpacing: '1px', color: active ? '#DC2626' : '#1A1A1A',
                background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Rubik', sans-serif",
              }}>
                {link}
                {active && <span style={{
                  position: 'absolute', bottom: 0, left: 0, right: 0, height: 3,
                  background: '#DC2626', borderRadius: 2,
                }} />}
              </button>
            );
          })}
        </div>
      </div>
      <RQButton text="Request Quote" onClick={() => onNavigate('Contact')} />
    </nav>
  );
}

Object.assign(window, { RQNavbar });
