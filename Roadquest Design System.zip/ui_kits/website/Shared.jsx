// Roadquest Trucking Services — Shared Components
// Load with <script type="text/babel" src="Shared.jsx"></script>

const RQ_COLORS = {
  accent: '#DC2626',
  accentAlt: '#16A34A',
  bgPrimary: '#FFFFFF',
  bgSecondary: '#F5F5F5',
  textPrimary: '#1A1A1A',
  textSecondary: '#4A4A4A',
};

// ─── Button ───────────────────────────────────────────
function RQButton({ text, variant = 'primary', size = 'md', onClick, href }) {
  const sizes = {
    sm: { padding: '8px 18px', fontSize: '13px' },
    md: { padding: '11px 28px', fontSize: '15px' },
    lg: { padding: '14px 40px', fontSize: '17px' },
  };
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: '9999px', fontWeight: 600, cursor: 'pointer',
    fontFamily: "'Rubik', sans-serif", textDecoration: 'none',
    transition: 'all 0.2s', border: 'none', ...sizes[size],
  };
  const variants = {
    primary: { background: RQ_COLORS.accent, color: '#fff' },
    outline: { background: 'transparent', color: RQ_COLORS.accent, border: `2px solid ${RQ_COLORS.accent}` },
  };
  const [hovered, setHovered] = React.useState(false);
  const hoverStyle = variant === 'primary'
    ? { opacity: hovered ? 0.88 : 1 }
    : { background: hovered ? RQ_COLORS.accent : 'transparent', color: hovered ? '#fff' : RQ_COLORS.accent };

  const style = { ...base, ...variants[variant], ...hoverStyle };
  if (href) return <a href={href} style={style} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>{text}</a>;
  return <button style={style} onClick={onClick} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>{text}</button>;
}

// ─── Icon Circle ─────────────────────────────────────
function IconCircle({ icon, size = 44 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '9999px',
      background: RQ_COLORS.accent, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.4, flexShrink: 0,
    }}>
      {icon}
    </div>
  );
}

// ─── Section Heading ─────────────────────────────────
function SectionHeading({ title, subtitle, align = 'left' }) {
  return (
    <div style={{ textAlign: align, marginBottom: 20 }}>
      <h2 style={{ fontSize: 'clamp(1.6rem,3vw,2.5rem)', fontWeight: 800, color: RQ_COLORS.textPrimary, margin: 0 }}>
        {title}
      </h2>
      {subtitle && <p style={{ marginTop: 8, fontSize: 15, color: RQ_COLORS.textSecondary, maxWidth: 600 }}>{subtitle}</p>}
    </div>
  );
}

Object.assign(window, { RQButton, IconCircle, SectionHeading, RQ_COLORS });
