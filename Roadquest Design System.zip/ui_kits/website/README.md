# Roadquest Website — UI Kit

Interactive click-through prototype of the Roadquest Trucking Services marketing website.

## Pages
- **Home** — Hero, Why Us cards, Services grid, About teaser
- **About** — Hero image, Mission/Vision/Values/Fleet cards
- **Services** — Hero + 4 service cards
- **Fleet** — 3-column fleet vehicle cards
- **Contact** — Quote request form + contact info panel

## Components
| File | Description |
|---|---|
| `Shared.jsx` | `RQButton`, `IconCircle`, `SectionHeading`, `RQ_COLORS` |
| `Navbar.jsx` | `RQNavbar` — sticky nav with active state + CTA |
| `Footer.jsx` | `RQFooter` — 4-column footer with social icons |
| `HomePage.jsx` | `HomePage` — full home page sections |
| `Pages.jsx` | `AboutPage`, `ServicesPage`, `FleetPage`, `ContactPage` |

## Design Decisions
- Font: Rubik (Google Fonts), 400/500/700/800/900
- Accent: `#DC2626` red for CTAs, icons, highlights
- Accent Alt: `#16A34A` green for trust signals, footer section titles
- All buttons are `border-radius: 9999px` (pill)
- Cards use `border-radius: 12px` + `box-shadow` elevation
- Hover on cards: border switches to accent color, shadow deepens
- No gradients, no decorative patterns
