// Roadquest — About, Services, Fleet, Contact Pages

function AboutPage() {
  const sections = [
    { heading: 'About Roadquest Trucking Services', img: '../assets/about-us.jpg', reverse: false,
      text: 'Established in 2025, Roadquest Trucking Services is a sole proprietorship based in Marilao, Bulacan. We specialize in provincial deliveries and container hauling across Luzon, Visayas, and Mindanao, serving manufacturers, distributors, retail chains, and SMEs.' },
    { heading: 'Our Mission', img: '../assets/engineer.jpg', reverse: true,
      text: 'To provide safe, reliable, and cost-efficient trucking services that connect businesses and communities across the Philippines, ensuring on-time deliveries and excellent customer care.' },
    { heading: 'Our Vision', img: '../assets/project-1.jpg', reverse: false,
      text: 'To be the most trusted and preferred trucking company in the Philippines, recognized for excellence in service, innovation in logistics, and commitment to customer satisfaction.' },
    { heading: 'Our Fleet', img: '../assets/fleet-preview.jpg', reverse: true,
      text: 'Our fleet of closed vans, wing vans, and trailer trucks is regularly maintained to ensure safe and timely deliveries across every major route in Luzon, Visayas, and Mindanao.' },
  ];

  return (
    <div style={{ fontFamily: "'Rubik', sans-serif" }}>
      {/* Hero */}
      <div style={{ position: 'relative', height: 320, borderRadius: 12, overflow: 'hidden', margin: '0 0 40px' }}>
        <img src="../assets/about-us.jpg" alt="Hero" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(26,26,26,.52)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 24 }}>
          <h1 style={{ color: '#fff', fontSize: 'clamp(2rem,4vw,3rem)', fontWeight: 900, margin: '0 0 10px' }}>Roadquest Trucking Services</h1>
          <p style={{ color: 'rgba(255,255,255,.88)', fontSize: 17, maxWidth: 500, margin: 0 }}>Safe, reliable, and cost-efficient logistics across Luzon, Visayas, and Mindanao.</p>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24, paddingBottom: 40 }}>
        {sections.map(s => (
          <div key={s.heading} style={{
            display: 'flex', flexDirection: s.reverse ? 'row-reverse' : 'row',
            gap: 32, alignItems: 'center', background: '#fff', borderRadius: 16,
            boxShadow: '0 4px 12px rgba(0,0,0,.07)', padding: 28,
          }}>
            <div style={{ flex: 1 }}>
              <h2 style={{ fontSize: 24, fontWeight: 800, color: '#DC2626', margin: '0 0 10px' }}>{s.heading}</h2>
              <p style={{ fontSize: 15, color: '#4A4A4A', lineHeight: 1.7, margin: 0 }}>{s.text}</p>
            </div>
            <div style={{ flex: 1 }}>
              <img src={s.img} alt={s.heading} style={{ width: '100%', height: 220, objectFit: 'cover', borderRadius: 12, display: 'block' }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ServicesPage() {
  const services = [
    { title: 'Provincial Deliveries', desc: 'Reliable door-to-door deliveries across all provinces in Luzon, Visayas, and Mindanao, ensuring your goods arrive safely and on time.' },
    { title: 'Container Hauling', desc: 'Efficient hauling of 20ft and 40ft containers from ports to warehouses or business locations nationwide.' },
    { title: 'Closed Van Transport', desc: 'Secure, weather-protected transport for goods requiring enclosed delivery using our fleet of closed vans.' },
    { title: 'Wing Van & Trailer Trucks', desc: 'High-capacity wing van and trailer truck services for bulk shipments and large-volume logistics requirements.' },
  ];

  return (
    <div style={{ fontFamily: "'Rubik', sans-serif" }}>
      <div style={{ position: 'relative', height: 260, borderRadius: 12, overflow: 'hidden', marginBottom: 40 }}>
        <img src="../assets/header-image.jpg" alt="Services" style={{ width:'100%', height:'100%', objectFit:'cover' }} />
        <div style={{ position:'absolute', inset:0, background:'rgba(26,26,26,.52)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', textAlign:'center', padding:24 }}>
          <h1 style={{ color:'#fff', fontSize:'clamp(2rem,4vw,3rem)', fontWeight:900, margin:'0 0 8px' }}>Our Services</h1>
          <p style={{ color:'rgba(255,255,255,.88)', fontSize:16, maxWidth:500, margin:0 }}>Logistics solutions across Luzon, Visayas, and Mindanao — built for manufacturers, distributors, retail chains, and SMEs.</p>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, paddingBottom: 40 }}>
        {services.map(s => (
          <div key={s.title} style={{
            background:'#fff', borderRadius:14, boxShadow:'0 4px 12px rgba(0,0,0,.08)',
            display:'flex', flexDirection:'column', alignItems:'center', textAlign:'center', padding:24, gap:12,
          }}>
            <div style={{ width:130, height:120, borderRadius:10, overflow:'hidden' }}>
              <img src="../assets/header-image.jpg" alt={s.title} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
            </div>
            <div style={{ fontWeight:700, fontSize:16, color:'#DC2626' }}>{s.title}</div>
            <div style={{ fontSize:13, color:'#4A4A4A', lineHeight:1.6 }}>{s.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FleetPage() {
  const fleet = [
    { title: 'Closed Van', img: '../assets/project-1.jpg', desc: 'Weather-protected enclosed transport. Ideal for retail goods and sensitive cargo.' },
    { title: 'Wing Van', img: '../assets/project-2.jpg', desc: 'Side-opening high-capacity van. Perfect for easy bulk loading and unloading.' },
    { title: 'Trailer Truck', img: '../assets/project-3.jpg', desc: 'Heavy-duty hauling for the largest shipments and container movements.' },
  ];

  return (
    <div style={{ fontFamily: "'Rubik', sans-serif", paddingBottom: 40 }}>
      <SectionHeading title="Our Fleet" subtitle="A modern, well-maintained fleet ready to move your cargo safely across every Philippine region." />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:24 }}>
        {fleet.map(f => (
          <div key={f.title} style={{
            background:'#fff', borderRadius:16, overflow:'hidden',
            boxShadow:'0 4px 12px rgba(0,0,0,.08)',
          }}>
            <img src={f.img} alt={f.title} style={{ width:'100%', height:200, objectFit:'cover', display:'block' }} />
            <div style={{ padding:20 }}>
              <h3 style={{ fontWeight:800, fontSize:20, color:'#DC2626', margin:'0 0 8px' }}>{f.title}</h3>
              <p style={{ fontSize:14, color:'#4A4A4A', margin:0, lineHeight:1.6 }}>{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContactPage() {
  const [form, setForm] = React.useState({ name:'', company:'', email:'', phone:'', service:'', message:'' });
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e) => { e.preventDefault(); setSubmitted(true); };

  return (
    <div style={{ fontFamily:"'Rubik', sans-serif", paddingBottom:40 }}>
      <SectionHeading title="Request a Quote" subtitle="Fill out the form below and our team will get back to you within 24 hours." />
      {submitted ? (
        <div style={{ textAlign:'center', padding:'60px 40px', background:'#fff', borderRadius:16, boxShadow:'0 4px 12px rgba(0,0,0,.08)' }}>
          <div style={{ width:64, height:64, borderRadius:'9999px', background:'#16A34A', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:28, margin:'0 auto 16px' }}>✓</div>
          <h2 style={{ fontWeight:800, fontSize:24, color:'#1A1A1A', margin:'0 0 8px' }}>Quote Request Sent!</h2>
          <p style={{ color:'#4A4A4A', fontSize:15 }}>We'll reach out to you within 24 hours. Thank you for choosing Roadquest.</p>
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:32 }}>
          <form onSubmit={handleSubmit} style={{ background:'#fff', padding:32, borderRadius:16, boxShadow:'0 4px 12px rgba(0,0,0,.08)', display:'flex', flexDirection:'column', gap:16 }}>
            {[
              { id:'name', label:'Full Name', placeholder:'Juan dela Cruz', type:'text' },
              { id:'company', label:'Company Name', placeholder:'Your Company Inc.', type:'text' },
              { id:'email', label:'Email Address', placeholder:'juan@company.com', type:'email' },
              { id:'phone', label:'Phone Number', placeholder:'+63 920-000-0000', type:'tel' },
            ].map(f => (
              <div key={f.id}>
                <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#1A1A1A', marginBottom:5 }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder} value={form[f.id]}
                  onChange={e => setForm(v => ({...v, [f.id]: e.target.value}))}
                  style={{ width:'100%', boxSizing:'border-box', padding:'10px 14px', borderRadius:8, border:'1px solid rgba(74,74,74,.3)', fontSize:14, fontFamily:"'Rubik',sans-serif", outline:'none' }}
                />
              </div>
            ))}
            <div>
              <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#1A1A1A', marginBottom:5 }}>Service Needed</label>
              <select value={form.service} onChange={e => setForm(v=>({...v,service:e.target.value}))}
                style={{ width:'100%', padding:'10px 14px', borderRadius:8, border:'1px solid rgba(74,74,74,.3)', fontSize:14, fontFamily:"'Rubik',sans-serif" }}>
                <option value="">Select a service…</option>
                <option>Provincial Deliveries</option>
                <option>Container Hauling</option>
                <option>Closed Van Transport</option>
                <option>Wing Van & Trailer Trucks</option>
              </select>
            </div>
            <div>
              <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#1A1A1A', marginBottom:5 }}>Message</label>
              <textarea placeholder="Describe your logistics needs…" value={form.message}
                onChange={e => setForm(v=>({...v,message:e.target.value}))}
                rows={4} style={{ width:'100%', boxSizing:'border-box', padding:'10px 14px', borderRadius:8, border:'1px solid rgba(74,74,74,.3)', fontSize:14, fontFamily:"'Rubik',sans-serif", resize:'vertical' }}
              />
            </div>
            <button type="submit" style={{ background:'#DC2626', color:'#fff', border:'none', borderRadius:'9999px', padding:'13px 32px', fontWeight:700, fontSize:16, cursor:'pointer', fontFamily:"'Rubik',sans-serif" }}>
              Send Request
            </button>
          </form>
          {/* Contact Info */}
          <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
            {[
              { icon:'📍', title:'Address', info:'9001 Laot Services Road Patubig, Marilao Bulacan' },
              { icon:'✉️', title:'Email', info:'roadquesttruckingservices@gmail.com' },
              { icon:'📞', title:'Phone', info:'+63 920-964-8531' },
              { icon:'⏰', title:'Hours', info:'24/7 — We dispatch and support whenever your business needs us.' },
            ].map(c => (
              <div key={c.title} style={{ display:'flex', gap:16, alignItems:'flex-start', background:'#fff', borderRadius:12, padding:'18px 20px', boxShadow:'0 2px 8px rgba(0,0,0,.06)' }}>
                <div style={{ fontSize:24, flexShrink:0 }}>{c.icon}</div>
                <div>
                  <div style={{ fontWeight:700, fontSize:15, color:'#1A1A1A', marginBottom:3 }}>{c.title}</div>
                  <div style={{ fontSize:13, color:'#4A4A4A', lineHeight:1.5 }}>{c.info}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { AboutPage, ServicesPage, FleetPage, ContactPage });
